A Pen created at CodePen.io. You can find this one at https://codepen.io/hollyos/pen/zwgRvY.

 A HTML5 & ES6 media player for a list of audio files. Served from a list of self created data objects. Would like to update to utilize an API for the data, if taking this further.  Oh, and it has hotkeys.

    a - previous
    d / n - next
    s / p - play / pause
    e / r - repeat
    q - shuffle